document.addEventListener("DOMContentLoaded", () => {
  const username = localStorage.getItem("loggedInUser");
  if (!username) window.location.href = "index.html";
  document.getElementById("user-display").textContent = username;

  const incomeEl = document.getElementById("income");
  const expenseEl = document.getElementById("expense");
  const balanceEl = document.getElementById("balance");
  const form = document.getElementById("transaction-form");
  const list = document.getElementById("transaction-list");
  const ctx = document.getElementById("expenseChart").getContext("2d");
  let transactions = JSON.parse(localStorage.getItem(username + "_transactions") || "[]");

  let chart;

  function render() {
    list.innerHTML = "";
    let income = 0, expense = 0;
    const categoryMap = {};

    transactions.forEach((t, i) => {
      if (t.type === "income") income += t.amount;
      else {
        expense += t.amount;
        categoryMap[t.category] = (categoryMap[t.category] || 0) + t.amount;
      }

      const li = document.createElement("li");
      li.textContent = `${t.desc} - ₹${t.amount} (${t.type})`;
      list.appendChild(li);
    });

    incomeEl.textContent = `Income: ₹${income}`;
    expenseEl.textContent = `Expense: ₹${expense}`;
    balanceEl.textContent = `Balance: ₹${income - expense}`;

    if (chart) chart.destroy();
    chart = new Chart(ctx, {
      type: "pie",
      data: {
        labels: Object.keys(categoryMap),
        datasets: [{
          data: Object.values(categoryMap),
          backgroundColor: ["#ef4444", "#3b82f6", "#10b981"]
        }]
      }
    });
  }

  form.addEventListener("submit", e => {
    e.preventDefault();
    const desc = document.getElementById("desc").value.trim();
    const amount = +document.getElementById("amount").value;
    const category = document.getElementById("category").value;
    const type = document.getElementById("type").value;
    transactions.push({ desc, amount, category, type });
    localStorage.setItem(username + "_transactions", JSON.stringify(transactions));
    form.reset();
    render();
  });

  render();
});

function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "index.html";
}
